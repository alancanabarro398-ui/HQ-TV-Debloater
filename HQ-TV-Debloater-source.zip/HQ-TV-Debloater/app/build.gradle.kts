plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "br.com.hqtv.debloater"
    compileSdk = 35

    defaultConfig {
        applicationId = "br.com.hqtv.debloater"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }
}

dependencies {
    implementation("dev.rikka.shizuku:api:13.1.5")
}
