package br.com.hqtv.debloater

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var packageArea: LinearLayout
    private val checks = linkedMapOf<String, CheckBox>()
    private val prefs by lazy { getSharedPreferences("hq_debloater", MODE_PRIVATE) }
    private val protected = listOf(
        "com.android.systemui", "com.android.settings", "com.android.providers",
        "com.android.packageinstaller", "com.google.android.packageinstaller",
        "com.google.android.gms", "com.android.vending", "com.android.inputdevices",
        "com.google.android.inputmethod", "com.android.tv.settings", "com.android.permissioncontroller",
        "com.google.android.tv.remote.service", "com.android.server.telecom"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        refreshPermissionState()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 32, 36, 40)
        }
        scroll.addView(root)
        setContentView(scroll)

        val title = TextView(this).apply {
            text = "HQ TV Debloater"
            textSize = 26f
            setTypeface(null, Typeface.BOLD)
        }
        root.addView(title)
        root.addView(TextView(this).apply {
            text = "Diagnóstico e gerenciamento reversível de apps Android TV • sem root"
            textSize = 14f
            setPadding(0, 8, 0, 20)
        })
        status = TextView(this).apply { textSize = 15f; setPadding(0, 8, 0, 16) }
        root.addView(status)
        addButton("1. Verificar Shizuku", ::refreshPermissionState)
        addButton("2. Solicitar autorização", ::requestShizuku)
        addButton("3. Fazer diagnóstico da TV", ::diagnose)
        addButton("4. Listar aplicativos instalados", ::loadPackages)
        addButton("5. Restaurar apps desativados por este app", ::restoreAll)
        root.addView(TextView(this).apply {
            text = "Aplicativos encontrados"
            textSize = 19f
            setTypeface(null, Typeface.BOLD)
            setPadding(0, 22, 0, 8)
        })
        root.addView(TextView(this).apply {
            text = "Marque apenas pacotes que você reconheceu. A identificação de anúncios é uma sugestão, não uma garantia. Não desative launcher, Google Play Services, configurações ou serviços essenciais."
            textSize = 13f
            setPadding(0, 0, 0, 12)
        })
        packageArea = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(packageArea)
        addButton("Desativar selecionados (com confirmação)", ::disableSelected)
    }

    private fun addButton(label: String, action: () -> Unit) {
        val b = Button(this).apply { text = label; isAllCaps = false }
        root.addView(b, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 8 })
        b.setOnClickListener { action() }
    }

    private fun refreshPermissionState() {
        val ready = try { Shizuku.pingBinder() && Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED } catch (_: Throwable) { false }
        status.text = if (ready) "● Shizuku conectado e autorizado. Pronto para diagnosticar." else "○ Shizuku ainda não está autorizado. Instale e inicie o Shizuku; depois autorize este aplicativo."
    }

    private fun requestShizuku() {
        try {
            if (!Shizuku.pingBinder()) {
                info("Shizuku não está em execução. Instale o Shizuku e inicie-o pela Depuração sem fio do Android.")
                return
            }
            if (Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                refreshPermissionState(); toast("Autorização já concedida")
            } else Shizuku.requestPermission(77)
        } catch (e: Throwable) { info("Não foi possível solicitar Shizuku: ${e.message}") }
    }

    private fun hasAccess(): Boolean = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) { false }

    private fun shell(command: String): String {
        check(hasAccess()) { "Shizuku não está conectado/autorizado." }
        val process = Shizuku.newProcess(arrayOf("sh", "-c", command), null, null)
        val out = process.inputStream.bufferedReader().readText()
        val err = process.errorStream.bufferedReader().readText()
        val code = process.waitFor()
        return (out + (if (err.isNotBlank()) "\n$err" else "") + "\n[código $code]").trim()
    }

    private fun diagnose() {
        runTask {
            val commands = listOf(
                "Fabricante" to "getprop ro.product.manufacturer",
                "Modelo" to "getprop ro.product.model",
                "Dispositivo" to "getprop ro.product.device",
                "Versão Android" to "getprop ro.build.version.release",
                "Build" to "getprop ro.build.display.id"
            )
            val result = commands.joinToString("\n\n") { (name, cmd) -> "$name:\n${shell(cmd)}" }
            runOnUiThread { info(result) }
        }
    }

    private fun loadPackages() {
        runTask {
            val result = shell("pm list packages")
            val names = result.lineSequence().map { it.trim().removePrefix("package:") }
                .filter { it.contains('.') && !it.startsWith("[") }.distinct().sorted().toList()
            runOnUiThread {
                checks.clear(); packageArea.removeAllViews()
                names.forEach { pkg ->
                    val cb = CheckBox(this).apply {
                        text = pkg + if (looksAdRelated(pkg)) "  • possível publicidade/recomendação" else ""
                        textSize = 13f
                        isEnabled = !isProtected(pkg)
                        if (isProtected(pkg)) text = "$pkg  • protegido"
                    }
                    checks[pkg] = cb
                    packageArea.addView(cb)
                }
                toast("${names.size} pacotes encontrados")
            }
        }
    }

    private fun looksAdRelated(pkg: String): Boolean {
        val p = pkg.lowercase()
        return listOf("adservice", "advert", "recommend", "sponsor", "promo", "marketing", "adview").any { p.contains(it) }
    }

    private fun isProtected(pkg: String): Boolean = protected.any { pkg == it || pkg.startsWith("$it.") } ||
        pkg.contains("launcher", true) || pkg.contains("inputmethod", true)

    private fun disableSelected() {
        val selected = checks.filterValues { it.isChecked && it.isEnabled }.keys.toList()
        if (selected.isEmpty()) { toast("Nenhum pacote selecionado"); return }
        AlertDialog.Builder(this)
            .setTitle("Confirmar desativação")
            .setMessage("Serão desativados estes pacotes:\n\n${selected.joinToString("\n")}\n\nIsso pode afetar funções da TV. A operação pode ser revertida pelo botão Restaurar, desde que os dados do app não sejam apagados. Continuar?")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Desativar") { _, _ ->
                runTask {
                    val done = mutableListOf<String>()
                    selected.forEach { pkg ->
                        if (!isProtected(pkg)) {
                            shell("pm disable-user --user 0 '$pkg'")
                            done.add(pkg)
                        }
                    }
                    val old = prefs.getStringSet("disabled", emptySet())?.toMutableSet() ?: mutableSetOf()
                    old.addAll(done); prefs.edit().putStringSet("disabled", old).apply()
                    runOnUiThread { toast("${done.size} pacote(s) desativado(s). Reinicie a TV e teste.") }
                }
            }.show()
    }

    private fun restoreAll() {
        val saved = prefs.getStringSet("disabled", emptySet())?.toList().orEmpty()
        if (saved.isEmpty()) { toast("Nenhum pacote registrado para restauração"); return }
        AlertDialog.Builder(this).setTitle("Restaurar aplicativos")
            .setMessage("Reativar ${saved.size} pacote(s) desativado(s) por este app?")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Restaurar") { _, _ -> runTask {
                saved.forEach { shell("pm enable '$it'") }
                prefs.edit().remove("disabled").apply()
                runOnUiThread { toast("Restauração solicitada") }
            } }.show()
    }

    private fun runTask(task: () -> Unit) {
        executor.execute {
            try { task() } catch (e: Throwable) { runOnUiThread { info("Erro: ${e.message}") } }
        }
    }

    private fun info(message: String) {
        AlertDialog.Builder(this).setTitle("HQ TV Debloater").setMessage(message)
            .setPositiveButton("OK", null).show()
    }
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    override fun onResume() { super.onResume(); refreshPermissionState() }
    override fun onDestroy() { super.onDestroy(); executor.shutdown() }
}
