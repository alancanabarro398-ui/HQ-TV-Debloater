# HQ TV Debloater (MVP 0.1.0)

Projeto Android Studio em Kotlin para diagnóstico e gerenciamento reversível de pacotes Android TV via Shizuku. Não requer root, mas requer que o usuário instale/inicie Shizuku e autorize o app.

## O que esta versão faz
- Verifica se Shizuku está conectado e autorizado.
- Lê fabricante, modelo, dispositivo, versão do Android e build.
- Lista os pacotes instalados na TV.
- Marca como sugestão apenas nomes com palavras como `adservice`, `advert`, `recommend`, `sponsor`, `promo`, `marketing` e `adview`.
- Permite desativação manual e individual/múltipla com confirmação usando `pm disable-user --user 0`.
- Guarda os pacotes desativados por este app e oferece restauração com `pm enable`.
- Bloqueia a seleção de pacotes que aparentam ser essenciais (System UI, Settings, Play Services, Play Store, launcher, teclado e alguns serviços críticos).

## Limitações importantes
- Esta é uma versão inicial, não uma IA autônoma. As palavras-chave são apenas pistas; não provam que um pacote exibe anúncios.
- Não desative pacotes apenas porque aparecem como sugestão. Envie primeiro o diagnóstico e a lista para revisão.
- O app não garante compatibilidade com todos os firmwares de TV HQ.
- O registro de restauração fica no armazenamento local do app. Não limpe os dados nem desinstale o app antes de restaurar.
- A lista de proteção é conservadora, mas não consegue conhecer todos os pacotes específicos do firmware HQ.
- A desativação de apps do sistema pode causar perda de recursos. Faça uma alteração por vez e teste a TV.

## Requisitos
- Android 6.0+ no celular (minSdk 23).
- Android Studio com JDK 17 e Android SDK 35 para compilar.
- Shizuku instalado no celular e iniciado por depuração sem fio/ADB. A versão do Android e as opções disponíveis variam por aparelho.
- Celular e TV na mesma rede Wi-Fi para o processo de configuração ADB do Shizuku.

## Como compilar
1. Abra esta pasta no Android Studio.
2. Aguarde a sincronização do Gradle.
3. Compile em **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Instale o APK gerado no celular.
5. Inicie Shizuku no celular conforme as instruções oficiais do Shizuku.
6. Abra HQ TV Debloater e conceda a permissão Shizuku.

## Fluxo seguro recomendado
1. Conectar Shizuku e confirmar status autorizado.
2. Executar diagnóstico e listar pacotes.
3. Guardar os resultados antes de qualquer alteração.
4. Revisar os nomes dos pacotes; não desativar launcher, configurações, serviços Google essenciais, teclado ou serviços de entrada.
5. Desativar um único pacote por vez, testar a TV e restaurar se houver problema.

## Dependência
`dev.rikka.shizuku:api:13.1.5`

Documentação do Shizuku: https://shizuku.rikka.app/
